class CongTy{
    constructor(){
        this.danhSachNhanVien = new Array();
    }

    //* Phương thức thêm nhân viên mới vào mảng (thuộc tính) DanhSachNhanVien
    themNhanVien(nhanVienMoi){
        //? this.danhSachNhanVien.push(nhanVienMoi) --> ES5
        this.danhSachNhanVien = [...this.danhSachNhanVien,nhanVienMoi] //?-ES6
    }

    //* Phương thức tìm nhân viên theo mã nhân viên, trả về vị trí nhân viên trong mảng danhSachNhanVien
    timViTriTheoMa(mnv){
        for(let vitri in this.danhSachNhanVien){
            if(this.danhSachNhanVien[vitri].maNV === mnv){
                return vitri;
                break;
            }
        }
    }

    //* Tìm nhân viên theo mã, trả về nhân viên
    timNhanVienTheoMa(mnv){
        for(let nhanVien of this.danhSachNhanVien){
            if(nhanVien.maNV === mnv){
                return nhanVien;
                break;
            }
            
        }
    }

    //* Xoá nhân viên theo mã
    xoaNhanVien(mnv){
        let vitri = this.timViTriTheoMa(mnv);
        this.danhSachNhanVien.splice(vitri,1);
    }

    //* Sửa thông tin nhân viên, nhập vào nhân viên --> sửa thông tin nhân viên
    suaNhanVien(nhanVien){
        let vitri = this.timViTriTheoMa(nhanVien.maNV);
        // console.log(this.danhSachNhanVien[vitri])
        // console.log(nhanVien)
        this.danhSachNhanVien[vitri] = nhanVien;
        console.log(this.danhSachNhanVien)
    }

    //*Tìm nhân viên theo tên ---> trả về danh sách nhân viên
    timNhanVienTheoTen(hoten){
        let dskq = new CongTy();
        hoten = hoten.trim().toUpperCase();

        for(let nhanVien of this.danhSachNhanVien){
            let hotenNV = nhanVien.hoTen.trim().toUpperCase();

            if(hotenNV.search(hoten) !== -1){
                dskq.danhSachNhanVien = [...dskq.danhSachNhanVien,nhanVien]
            }
        }
        return dskq;
    }

    sapXepNhanVien(type){
        if(type === 1){
            //tang dan
            this.danhSachNhanVien.sort((a,b)=>{
                let x = a.maNV.toUpperCase();
                let y = b.maNV.toUpperCase();
                if(x < y) {return -1};
                if(x > y) {return 1};
                return 0;
            })
        }else{
            //giam dan
            this.danhSachNhanVien.sort((a,b)=>{
                let x = a.maNV.toUpperCase();
                let y = b.maNV.toUpperCase();
                if(x > y) {return -1};
                if(x < y) {return 1};
                return 0;
            })
        }
    }
}




